JOHN NYAMBATI — PORTFOLIO WEBSITE

FILES
- index.html: the complete responsive website. No framework or paid software is required.

PREVIEW ON YOUR DEVICE
1. Extract the ZIP file.
2. Open index.html in Chrome or another browser.
3. On a phone/tablet, you can upload the file to a free hosting service to preview it online.

PUBLISH FREE WITH GITHUB PAGES
1. Create/sign in to a free account at https://github.com/
2. Create a new public repository, e.g. john-nyambati-portfolio.
3. Upload index.html from this folder to the repository's top level and commit the changes.
4. Open the repository Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch", select "main" and "/ (root)", then Save.
6. Wait a few minutes. GitHub will show your public website URL in Settings → Pages, usually:
   https://YOUR-USERNAME.github.io/john-nyambati-portfolio/
7. Share that URL with potential clients.

BEFORE SHARING
- The three project cards are sample concepts, not claims of completed client work. Replace them with your real work as you create it.
- Check that the email address shown on the page is correct.
- Add links to your professional profiles when you have them.
- A free GitHub Pages address is included; buying a custom domain is optional.

This is a static website and does not need a server, database, or paid hosting.
