SECRET GAME WEBSITE

Files:
- index.html: complete, mobile-friendly Secret Game website.

Try it:
1. Open index.html in a web browser to test it.

Publish free with GitHub Pages:
1. On GitHub, create a new public repository named secret-game.
2. Choose Add file > Upload files, and upload index.html from this folder.
3. Commit the upload.
4. Open the repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait a few minutes. GitHub will show the public website URL, usually:
   https://YOUR-GITHUB-USERNAME.github.io/secret-game/
8. Send that URL to your friend.

The website is not published yet; the public link only works after you complete the GitHub Pages steps.
